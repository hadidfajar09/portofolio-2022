
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `abouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abouts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_deskripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `long_deskripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `abouts` WRITE;
/*!40000 ALTER TABLE `abouts` DISABLE KEYS */;
INSERT INTO `abouts` VALUES (1,'Mochammad Hadiid Fajar','Ini adalah short title','HAAAAA','<p>Saya Adalah Hadiid atau yang biasa dikenal dengan nama Zeronine.</p>\r\n<p>Keseharian saya adalah sebagai seorang pengajar di salah satu sekolah berbasis sma di kota makassar yang insyaaAllah merupakan sekolah yang murni akan tauhid sehingga ber aqidah yang lurus...</p>','upload/slide/1739876017990905.jpg',NULL,'2022-10-03 01:01:41');
/*!40000 ALTER TABLE `abouts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `blog_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `blog_categories` WRITE;
/*!40000 ALTER TABLE `blog_categories` DISABLE KEYS */;
INSERT INTO `blog_categories` VALUES (1,'Programming','2022-10-06 04:58:14',NULL),(2,'Dakwah','2022-10-06 04:58:20',NULL);
/*!40000 ALTER TABLE `blog_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
INSERT INTO `blogs` VALUES (1,2,'Bela sungkawa','upload/blog/1745948430078238.png','damai','<p>gegege</p>','2022-10-06 06:22:55',NULL),(2,1,'Doa adalah ibadahdsadas','upload/blog/1746107409814587.PNG','halal','<p>dsadasdasdsadqw312dsadas</p>','2022-10-06 06:53:34','2022-10-08 00:29:50'),(4,1,'LARAVEL','upload/blog/1746099407860095.png','teas,dsadas,dasd','<p>dasdasdas</p>','2022-10-07 22:22:39',NULL);
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `home_slides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `home_slides` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deskripsi` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `home_slides` WRITE;
/*!40000 ALTER TABLE `home_slides` DISABLE KEYS */;
INSERT INTO `home_slides` VALUES (1,'Mochammad Hadiid Fajar','FullStack Web Developer','upload/slide/1739577762116665.jpg','https://www.youtube.com/watch?v=MojCUZ2Q_yQ',NULL,'2022-07-27 22:45:00');
/*!40000 ALTER TABLE `home_slides` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2022_07_23_153626_create_home_slides_table',2),(6,'2022_07_28_112723_create_abouts_table',3),(7,'2022_08_15_143936_create_multi_images_table',4),(8,'2022_10_03_093341_create_portfolios_table',5),(9,'2022_10_06_023204_create_blog_categories_table',6),(10,'2022_10_06_064717_create_blogs_table',6);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `multi_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `multi_images` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `multi_images` WRITE;
/*!40000 ALTER TABLE `multi_images` DISABLE KEYS */;
INSERT INTO `multi_images` VALUES (8,'upload/multi/1745655556812938.png','2022-10-03 00:47:40','2022-10-03 00:47:49'),(9,'upload/multi/1745657195749756.jpg','2022-10-03 01:09:04','2022-10-03 01:13:52'),(10,'upload/multi/1745656893715439.png','2022-10-03 01:09:04','2022-10-03 01:09:04'),(11,'upload/multi/1745656893796956.png','2022-10-03 01:09:04','2022-10-03 01:09:04'),(12,'upload/multi/1745657166451604.jfif','2022-10-03 01:09:04','2022-10-03 01:13:24'),(13,'upload/multi/1745656893849359.png','2022-10-03 01:09:05','2022-10-03 01:09:05'),(14,'upload/multi/1745656893956104.jpg','2022-10-03 01:09:05','2022-10-03 01:09:05'),(15,'upload/multi/1745656893987435.jpg','2022-10-03 01:09:05','2022-10-03 01:09:05');
/*!40000 ALTER TABLE `multi_images` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('fajarnet1999@gmail.com','$2y$10$0F3Bu2sZYvADO2Za6KwRguvmA0kinCPwj/X90Cp5.bGaUDcDLU2te','2022-07-22 03:23:30');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `portfolios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portfolios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `portfolios` WRITE;
/*!40000 ALTER TABLE `portfolios` DISABLE KEYS */;
INSERT INTO `portfolios` VALUES (1,'Website Portfolio','Website dibangun menggunakan Laravel 8','upload/porto/1745683578126845.png','<p>Teknologi yang saya gunakan :</p>\r\n<p>1. Laravel</p>\r\n<p>2. Bootsrap</p>\r\n<p>3. Ajax</p>',NULL,NULL),(2,'SUGIYONO','dasdasdas','upload/porto/1745757502730183.png','<p>dasdasdasdas</p>','2022-10-04 03:48:13',NULL),(3,'Pangkalan 01','NETRAL','upload/porto/1745758992808813.jfif','<table role=\"presentation\" border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\r\n<tbody>\r\n<tr>\r\n<td align=\"center\">\r\n<div>\r\n<p>Time to start planning your New Year\'s resolutions! Hoping to learn some new skills? Now&rsquo;s your chance to enroll in Dribbble&rsquo;s immersive&nbsp;<a class=\"m_-2603131397231006222vdt_link\" href=\"https://email.n.dribbble.com/c/eJytUk1vozAQ_TVwiYhgzJcPHFpI2tV2q7bbqttckLFNYpYvGROa_vo1lGzovRKShzfP82bemJKqJWJfG9615FS0gtcqZU1FhIaSaK-Dck2byuSR4_tuaLsBYJNFzIcAfJNerh-JFESJZroXN7WSTWmKCGwAx7aRg1wP8BoowyR0IchySnmIDdeu10yKLMtKPgkdosxHmDrgYuJjYIGf55SjDFPXoZnjOZkpo5wURNZcORiPJS5tltFBqbYz0JUBW_0tS-tf2vSy452OemEx3o2toy0TnU7UykCJhj85FnhWk-cG-L2q0k5jlOv8kctmxirORF9pjI_qM0j14HyqRD8tOONno1Di2Gsb1gDphvV0ciy950NXcqW4nOk6Git_wUfpVDANf5kevMX8Z5oWP2riL1xu7gLr8Wffs6J6rz5eX15-7K72h5uH4unh1A7NySruGufttkgAv-_KrjgiIbxkkOE-YfkNPD_G98NTHsTxc_Hm_B7a1w_r7-bPbkDMinvkuVofJct30PVZwakaX0EyGbw6afNWBoSz34BXlEjONbYBA8dGuDU2W-M61MGy0DkcZ9bFxkcUIHfJaGUzSqU1qfikNy97yVGndspdrFxmp9Wl39ay4lVbEsX_d2SqaNzHfFjzDPrECPnBP6KJJMA\" target=\"_blank\" rel=\"noopener\" data-saferedirecturl=\"https://www.google.com/url?q=https://email.n.dribbble.com/c/eJytUk1vozAQ_TVwiYhgzJcPHFpI2tV2q7bbqttckLFNYpYvGROa_vo1lGzovRKShzfP82bemJKqJWJfG9615FS0gtcqZU1FhIaSaK-Dck2byuSR4_tuaLsBYJNFzIcAfJNerh-JFESJZroXN7WSTWmKCGwAx7aRg1wP8BoowyR0IchySnmIDdeu10yKLMtKPgkdosxHmDrgYuJjYIGf55SjDFPXoZnjOZkpo5wURNZcORiPJS5tltFBqbYz0JUBW_0tS-tf2vSy452OemEx3o2toy0TnU7UykCJhj85FnhWk-cG-L2q0k5jlOv8kctmxirORF9pjI_qM0j14HyqRD8tOONno1Di2Gsb1gDphvV0ciy950NXcqW4nOk6Git_wUfpVDANf5kevMX8Z5oWP2riL1xu7gLr8Wffs6J6rz5eX15-7K72h5uH4unh1A7NySruGufttkgAv-_KrjgiIbxkkOE-YfkNPD_G98NTHsTxc_Hm_B7a1w_r7-bPbkDMinvkuVofJct30PVZwakaX0EyGbw6afNWBoSz34BXlEjONbYBA8dGuDU2W-M61MGy0DkcZ9bFxkcUIHfJaGUzSqU1qfikNy97yVGndspdrFxmp9Wl39ay4lVbEsX_d2SqaNzHfFjzDPrECPnBP6KJJMA&amp;source=gmail&amp;ust=1664971831972000&amp;usg=AOvVaw184klRvXrBEj-x3MoCXavp\">4-Week Introduction to UI Design Course</a>&nbsp;starting on January 9, 2023.&nbsp;</p>\r\n</div>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td class=\"m_-2603131397231006222vdt_hide-on-mobile\" align=\"left\">\r\n<div>\r\n<ul>\r\n<li><img class=\"an1\" src=\"https://fonts.gstatic.com/s/e/notoemoji/14.0/1f3a8/32.png\" alt=\"🎨\" loading=\"lazy\" data-emoji=\"🎨\" aria-label=\"🎨\" />&nbsp;Master Figma &amp; FigJam fundamentals</li>\r\n<li><img class=\"an1\" src=\"https://fonts.gstatic.com/s/e/notoemoji/14.0/270f_fe0f/32.png\" alt=\"✏️\" loading=\"lazy\" data-emoji=\"✏️\" aria-label=\"✏️\" />&nbsp;Learn key user interface design principles</li>\r\n<li><img class=\"an1\" src=\"https://fonts.gstatic.com/s/e/notoemoji/14.0/2699_fe0f/32.png\" alt=\"⚙️\" loading=\"lazy\" data-emoji=\"⚙️\" aria-label=\"⚙️\" />&nbsp;Apply UI design processes &amp; workflows</li>\r\n<li><img class=\"an1\" src=\"https://fonts.gstatic.com/s/e/notoemoji/14.0/1f4da/32.png\" alt=\"📚\" loading=\"lazy\" data-emoji=\"📚\" aria-label=\"📚\" />&nbsp;Create clear, well-structured UI libraries</li>\r\n<li><img class=\"an1\" src=\"https://fonts.gstatic.com/s/e/notoemoji/14.0/2728/32.png\" alt=\"✨\" loading=\"lazy\" data-emoji=\"✨\" aria-label=\"✨\" />&nbsp;Develop realistic and fully-functional prototypes!</li>\r\n</ul>\r\n</div>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>','2022-10-04 04:11:54',NULL);
/*!40000 ALTER TABLE `portfolios` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'zeronine09','','zeronine09@gmail.com',NULL,'2022-07-18 00:30:36','$2y$10$JmWXQKFtVchZJAT5MVg7BONJrXjugZGLcaEBOrFaFK8IEcECOMAIG','RXdFk8jEQDxvyGADSj3hgHiwjrHiTlyepJPvuGgxIYSIJqlP1gni0onIkrdT','2022-07-17 22:49:10','2022-07-18 00:30:36'),(2,'fajarnet09','hadidfajar09','fajarnet1999@gmail.com','upload/images/20220723032752images.jfif','2022-07-19 00:23:52','$2y$10$r9.dsU/iCes7s2m5XsMZ..Q61MjyvZmu2LZ8rj5YNDDn57xJbc/oW',NULL,'2022-07-19 00:23:31','2022-07-22 22:02:32'),(3,'Pangkalan 01','tester09','bupati@go.id','upload/images/20220722074838slider-2022-06-13202128.jpeg','2022-07-20 00:22:34','$2y$10$vQ.EBz9bA1xeuOPyvap01.s3DhUZrR64CRNDHf2K4uaMlyp8hdpf2','adFolSGBCW7FAh0mVUE9vc3oQhitreOtwvPq8ZeLsnSbFdE0sHMa7NzFSY75','2022-07-19 23:46:43','2022-07-21 23:48:38');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

